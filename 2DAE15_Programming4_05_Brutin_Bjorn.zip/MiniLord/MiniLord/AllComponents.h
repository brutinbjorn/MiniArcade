#pragma once
#include "Component.h"
#include "RenderComponent.h"
#include "TextComponent.h"
#include "SpriteComponent.h"
#include "RectComponent.h"
