// main.cpp : This file contains the 'main' function. Program execution begins and ends there.
//
#include "MiniLordPCH.h"
#include "MiniEngine.h"

int main(int, char* [])
{
	MiniLord::MiniEngine engine;
    engine.run();
    return 0;
}

