#include "MiniLordPCH.h"
#include "BaseComponent.h"
