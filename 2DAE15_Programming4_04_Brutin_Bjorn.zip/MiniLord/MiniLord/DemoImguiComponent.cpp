#include "MiniLordPCH.h"
#include "DemoImguiComponent.h"

#include "imgui.h"
using namespace MiniLord;
void DemoImguiComponent::GuiRender()

{
	ImGui::ShowDemoWindow();
}
